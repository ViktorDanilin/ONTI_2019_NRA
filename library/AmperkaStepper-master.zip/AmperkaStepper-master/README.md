AmperkaStepper
==============

Библиотека для Arduino позволящая управлять шаговыми двигателями, подключёнными
к [Motor Shield](http://amperka.ru/product/arduino-motor-shield) или [Motor Shield Plus](http://amperka.ru/product/arduino-motor-shield-plus).

Установка библиотеки
====================

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.
